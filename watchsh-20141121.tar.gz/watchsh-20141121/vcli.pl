#! /usr/bin/env perl

# vcli.pl
# A perl wrapper for mpv/MPlayer to run videos easy via CLI.
# vcli.pl © 2014 deterenkelt.

# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published
# by the Free Software Foundation; either version 3 of the License,
# or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but without any warranty; without even the implied warranty
# of merchantability or fitness for a particular purpose.
# See the GNU General Public License for more details.


# Requires
# GNU sed >= 4.2.1 (started developing with it)
# GNU grep >= 2.9 (started developing with it)
# ??? perl >= 5.20.1
# file >= 5.17 (output format of that utility has been changing,
#     vcli.pl conforms with 5.17 since v????????)
# util-linux >= 2.20 (for getopt that is required, and taskset
#     which may be of use, but is optional)
# mpv, mplayer2 or mplayer. Syntax was optimized
#     for the first and the latter.
#
# Works better with
# GNU parallel — to compress screenshots faster using all cores available
#       (or those available after restricting to those specified
#        to the -t or --taskset option.)
# figlet — to draw last seen episode number with big ASCII art numbers.
# pngcrush — helps to reduce PNG image size, if you prefer it over JPEG.
#       (players tend to save PNG in an unoptimized format, which makes
#        screenshots very large. pngcrush recompresses them without quality
#        loss.)
# pngtopam and cjpeg — are only needed for converting screenshots from PNG
#       (if you, for some reason use MPlayer, that can only save them to PNG)
#        to JPEG by the usage of --jpeg-compression. pngtopam is usually found
#        in the netpbm package and cjpeg in libjpeg-turbo.


use strict;
use warnings;

